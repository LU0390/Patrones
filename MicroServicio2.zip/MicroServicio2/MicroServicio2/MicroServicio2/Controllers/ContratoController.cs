﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using MediatR;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Services.Contratos.Commands;
using Services.Contratos.Forms;
using Services.Contratos.Queries;

namespace Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ContratoController : ControllerBase
    {
        private readonly IMediator _mediator;

        public ContratoController(IMediator mediator)
        {
            _mediator = mediator;
        }

        [HttpGet]
        public async Task<IActionResult> ObtenerContratos() =>
            Ok(await _mediator.Send(new ObtenerContratosQuery()));

        [HttpGet]
        [Route("GetContratoById/{contratoId}")]
        public async Task<IActionResult> GetContratoById(int contratoId) =>
            Ok(await _mediator.Send(new ObtenerContratosByIdQuery(contratoId)));

        [HttpGet]
        [Route("GetContratoByEmpleadoId/{empleadoId}")]
        public async Task<IActionResult> GetContratoByempleadoId(int empleadoId) =>
            Ok(await _mediator.Send(new ObtenerContratoByEmpleadoQuery(empleadoId)));

        [HttpPost]
        public async Task<IActionResult> InsertarContrato([FromBody] InsertContratoForm contrato) =>
            Ok(await _mediator.Send(new InsertContratoCommand(contrato)));

        [HttpDelete]
        public async Task<IActionResult> BorrarContrato(int empleadoId) =>
            Ok(await _mediator.Send(new DeleteContratoCommand(empleadoId)));

    }
}