﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    [Serializable]
    public class Contrato
    {
        public int Id    { get; set; }
        public int EmpleadoId { get; set; }
        public double Sueldo { get; set; }
        public DateTime FechaIngreso { get; set; }
        public TipoContratoEnum TipoContrato { get; set; }
    }

    public enum TipoContratoEnum
    {
        PLAZO_FIJO = 1,
        INDETERMINADO = 2
    }
}
