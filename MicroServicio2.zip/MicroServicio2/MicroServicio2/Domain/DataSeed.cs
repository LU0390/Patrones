﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Domain
{
    public static class DataSeed
    {
        public static List<Contrato> Contratos = new List<Contrato>
        {
            {new Contrato{Id = 1, EmpleadoId = 1, Sueldo = 50233.98, FechaIngreso = new DateTime(2020, 5, 2),TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 2, EmpleadoId = 2, Sueldo = 50938.9, FechaIngreso = new DateTime(2018, 4, 3),
            TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 3, EmpleadoId = 3, Sueldo = 98423.8, FechaIngreso = new DateTime(2019,9,8),
            TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 4, EmpleadoId = 4, Sueldo = 93855, FechaIngreso = DateTime.Now, TipoContrato = TipoContratoEnum.PLAZO_FIJO} },
            {new Contrato{Id = 5, EmpleadoId = 5, Sueldo = 84758, FechaIngreso = new DateTime(2019, 5, 4), TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 6, EmpleadoId = 6, Sueldo = 57573, FechaIngreso = new DateTime(2020, 9, 4),
            TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 7, EmpleadoId = 7, Sueldo = 95859, FechaIngreso = new DateTime(2020, 9 , 3), TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 8, EmpleadoId = 8, Sueldo = 947292, FechaIngreso = DateTime.Now, TipoContrato = TipoContratoEnum.PLAZO_FIJO} },
            {new Contrato{Id = 9, EmpleadoId = 9, Sueldo = 48392, FechaIngreso = new DateTime(2011, 5, 3), TipoContrato = TipoContratoEnum.INDETERMINADO} },
            {new Contrato{Id = 10, EmpleadoId = 10, Sueldo = 50000, FechaIngreso = DateTime.Now, TipoContrato = TipoContratoEnum.PLAZO_FIJO} }
        };
    }
}
