﻿using Domain;
using System;
using System.Collections.Generic;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Text;

namespace Services
{
    public static class ContratoCollectionHelper
    {
        public static void SaveContext(this List<Contrato> contratos)
        {
            BinaryFormatter formateador = new BinaryFormatter();
            Stream stream = new FileStream("Contratos.json", FileMode.Create, FileAccess.Write, FileShare.None);
            formateador.Serialize(stream, contratos);
            stream.Close();

        }

        public static List<Contrato> Restaurar()
        {
            BinaryFormatter formateador = new BinaryFormatter();
            Stream stream = new FileStream("Contratos.json", FileMode.Open, FileAccess.Read, FileShare.None);
            List<Contrato> temp = (List<Contrato>)formateador.Deserialize(stream);
            stream.Close();

            return temp;
        }
    }
}
