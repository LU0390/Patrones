﻿using Domain;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Forms
{
    public abstract class ContratoForm
    {
        public int EmpleadoId { get; set; }
        public double Sueldo { get; set; }
        public DateTime FechaIngreso { get; set; }
        public TipoContratoEnum TipoContrato { get; set; }
    }
}
