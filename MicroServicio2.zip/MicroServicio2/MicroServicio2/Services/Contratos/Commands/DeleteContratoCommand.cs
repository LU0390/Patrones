﻿using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Commands
{
    public class DeleteContratoCommand : IRequest<bool>
    {
        public int EmpleadoId { get; }
        public DeleteContratoCommand(int empleadoId)
        {
            EmpleadoId = empleadoId;
        }
    }
}
