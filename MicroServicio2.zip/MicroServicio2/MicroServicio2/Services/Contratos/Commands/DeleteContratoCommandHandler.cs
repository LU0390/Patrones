﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services.Contratos.Commands
{
    public class DeleteContratoCommandHandler : IRequestHandler<DeleteContratoCommand, bool>
    {
        private List<Contrato> _contratos;
        public DeleteContratoCommandHandler() => _contratos = ContratoCollectionHelper.Restaurar();

        public async Task<bool> Handle(DeleteContratoCommand request, CancellationToken cancellationToken)
        {
            var contrato = _contratos.FirstOrDefault(x => x.EmpleadoId == request.EmpleadoId);
            _contratos.Remove(contrato);
            _contratos.SaveContext();

            if (_contratos.Contains(contrato))
                return false;

            return true;
        }
    }
}
