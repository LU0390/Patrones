﻿using Domain;
using MediatR;
using Services.Contratos.Forms;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Commands
{
    public class InsertContratoCommand : IRequest<Contrato>
    {
        public InsertContratoForm Contrato { get; }
        public InsertContratoCommand(InsertContratoForm contrato)
        {
            Contrato = contrato;
        }
    }
}
