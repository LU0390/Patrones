﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services.Contratos.Commands
{
    public class InsertContratoCommandHandler : IRequestHandler<InsertContratoCommand, Contrato>
    {
        private List<Contrato> _contratos;
        public InsertContratoCommandHandler() => _contratos = ContratoCollectionHelper.Restaurar();

        public async Task<Contrato> Handle(InsertContratoCommand request, CancellationToken cancellationToken)
        {
            var idMasAlto = _contratos.OrderByDescending(x => x.Id).FirstOrDefault().Id;
            Contrato contrato = new Contrato
            {
                Id = idMasAlto + 1,
                EmpleadoId = request.Contrato.EmpleadoId,
                FechaIngreso = request.Contrato.FechaIngreso,
                Sueldo = request.Contrato.Sueldo,
                TipoContrato = request.Contrato.TipoContrato
            };
            _contratos.Add(contrato);
            _contratos.SaveContext();
            return contrato;
        }
    }
}
