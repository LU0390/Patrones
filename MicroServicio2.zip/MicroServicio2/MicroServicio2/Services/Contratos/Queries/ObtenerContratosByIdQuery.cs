﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Queries
{
    public class ObtenerContratosByIdQuery : IRequest<Contrato>
    {
        public int Id { get; }
        public ObtenerContratosByIdQuery(int id)
        {
            Id = id;
        }
    }
}
