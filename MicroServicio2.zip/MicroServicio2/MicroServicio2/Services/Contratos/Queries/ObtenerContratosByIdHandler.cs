﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services.Contratos.Queries
{
    public class ObtenerContratosByIdHandler : IRequestHandler<ObtenerContratosByIdQuery, Contrato>
    {
        private List<Contrato> _contratos;
        public ObtenerContratosByIdHandler()
        {
            _contratos = ContratoCollectionHelper.Restaurar();
        }

        public async Task<Contrato> Handle(ObtenerContratosByIdQuery request, CancellationToken cancellationToken)
        {
            return _contratos.FirstOrDefault(x => x.Id == request.Id);
        }
    }
}
