﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Queries
{
    public class ObtenerContratoByEmpleadoQuery : IRequest<Contrato>
    {
        public int EmpleadoId { get; }
        public ObtenerContratoByEmpleadoQuery(int empleadoId)
        {
            EmpleadoId = empleadoId;
        }
    }
}
