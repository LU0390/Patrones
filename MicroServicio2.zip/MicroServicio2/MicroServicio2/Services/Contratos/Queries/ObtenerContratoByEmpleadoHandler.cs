﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services.Contratos.Queries
{
    public class ObtenerContratoByEmpleadoHandler : IRequestHandler<ObtenerContratoByEmpleadoQuery, Contrato>
    {
        private List<Contrato> _contratos;
        public ObtenerContratoByEmpleadoHandler()
        {
            _contratos = ContratoCollectionHelper.Restaurar();
        }

        public async Task<Contrato> Handle(ObtenerContratoByEmpleadoQuery request, CancellationToken cancellationToken)
        {
            return _contratos.FirstOrDefault(x => x.EmpleadoId == request.EmpleadoId);
        }
    }
}
