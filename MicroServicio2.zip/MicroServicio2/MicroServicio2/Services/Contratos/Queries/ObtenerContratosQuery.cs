﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;

namespace Services.Contratos.Queries
{
    public class ObtenerContratosQuery : IRequest<List<Contrato>>
    {
    }
}
