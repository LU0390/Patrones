﻿using Domain;
using MediatR;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace Services.Contratos.Queries
{
    public class ObtenerContratosQueryHandler : IRequestHandler<ObtenerContratosQuery, List<Contrato>>
    {
        private List<Contrato> _contratos;
        public ObtenerContratosQueryHandler()
        {
            _contratos = ContratoCollectionHelper.Restaurar();
        }

        public async Task<List<Contrato>> Handle(ObtenerContratosQuery request, CancellationToken cancellationToken)
        {
            return _contratos;
        }
    }
}
